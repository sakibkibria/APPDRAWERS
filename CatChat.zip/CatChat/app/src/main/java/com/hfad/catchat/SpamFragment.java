package com.hfad.catchat;

//import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by sakib_kibria on 10/25/17.
 */

public class SpamFragment extends Fragment { public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                                                      Bundle savedInstanceState) {
    return inflater.inflate(R.layout.fragment_spam, container, false);
}
}

